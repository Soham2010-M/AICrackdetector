import os
import uuid
from flask import render_template, request, redirect, url_for, flash, send_file, jsonify
from werkzeug.utils import secure_filename
from app import app, db
from models import InspectionReport, DefectDetail
from defect_detector import DefectDetector
from report_generator import ReportGenerator
import logging

# Configure allowed extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'bmp', 'tiff', 'webp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Main dashboard showing recent inspections and statistics"""
    recent_reports = InspectionReport.query.order_by(InspectionReport.created_at.desc()).limit(5).all()
    
    # Calculate statistics
    total_inspections = InspectionReport.query.count()
    high_risk_count = InspectionReport.query.filter_by(overall_severity='high').count()
    
    stats = {
        'total_inspections': total_inspections,
        'high_risk_inspections': high_risk_count,
        'recent_reports': recent_reports
    }
    
    return render_template('index.html', stats=stats)

@app.route('/upload')
def upload():
    """Upload page for new inspections"""
    return render_template('upload.html')

@app.route('/process_upload', methods=['POST'])
def process_upload():
    """Process uploaded image and perform defect detection"""
    if 'file' not in request.files:
        flash('No file selected', 'error')
        return redirect(url_for('upload'))
    
    file = request.files['file']
    if file.filename == '':
        flash('No file selected', 'error')
        return redirect(url_for('upload'))
    
    if not allowed_file(file.filename):
        flash('Invalid file type. Please upload an image file.', 'error')
        return redirect(url_for('upload'))
    
    try:
        # Generate unique filename
        unique_filename = str(uuid.uuid4()) + '_' + secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(filepath)
        
        # Get form data
        infrastructure_type = request.form.get('infrastructure_type', 'General')
        location = request.form.get('location', '')
        inspector_notes = request.form.get('inspector_notes', '')
        
        # Create new inspection report
        report = InspectionReport(
            filename=file.filename,
            original_path=filepath,
            infrastructure_type=infrastructure_type,
            location=location,
            inspector_notes=inspector_notes
        )
        
        db.session.add(report)
        db.session.commit()
        
        # Perform defect detection
        detector = DefectDetector()
        detection_results = detector.detect_defects(filepath)
        
        # Save processed image
        processed_filename = f"processed_{unique_filename}"
        processed_path = os.path.join(app.config['PROCESSED_FOLDER'], processed_filename)
        detector.save_annotated_image(processed_path)
        
        report.processed_path = processed_path
        
        # Calculate overall statistics
        total_defects = 0
        risk_score = 0.0
        severity_counts = {'low': 0, 'medium': 0, 'high': 0}
        
        # Process detection results and create defect details
        for detection in detection_results:
            defect = DefectDetail(
                report_id=report.id,
                defect_type=detection['type'],
                severity=detection['severity'],
                confidence=detection['confidence'],
                x_min=detection['bbox'][0],
                y_min=detection['bbox'][1],
                x_max=detection['bbox'][2],
                y_max=detection['bbox'][3],
                area=detection.get('area', 0),
                length=detection.get('length', 0),
                width=detection.get('width', 0),
                description=detection.get('description', ''),
                recommendation=detection.get('recommendation', '')
            )
            
            db.session.add(defect)
            total_defects += 1
            severity_counts[detection['severity']] += 1
            
            # Update type-specific counts
            if detection['type'] == 'crack':
                report.crack_count += 1
            elif detection['type'] == 'corrosion':
                report.corrosion_count += 1
            elif detection['type'] == 'spalling':
                report.spalling_count += 1
            elif detection['type'] == 'structural_damage':
                report.structural_damage_count += 1
        
        # Calculate overall severity and risk score
        if severity_counts['high'] > 0:
            report.overall_severity = 'high'
            risk_score = 0.8 + (severity_counts['high'] * 0.05)
        elif severity_counts['medium'] > 0:
            report.overall_severity = 'medium'  
            risk_score = 0.4 + (severity_counts['medium'] * 0.03)
        else:
            report.overall_severity = 'low'
            risk_score = 0.1 + (severity_counts['low'] * 0.02)
        
        report.total_defects = total_defects
        report.risk_score = min(1.0, risk_score)  # Cap at 1.0
        
        db.session.commit()
        
        flash('Image processed successfully!', 'success')
        return redirect(url_for('view_results', report_id=report.id))
        
    except Exception as e:
        logging.error(f"Error processing upload: {str(e)}")
        flash(f'Error processing image: {str(e)}', 'error')
        return redirect(url_for('upload'))

@app.route('/results/<int:report_id>')
def view_results(report_id):
    """View detection results for a specific report"""
    report = InspectionReport.query.get_or_404(report_id)
    defects = DefectDetail.query.filter_by(report_id=report_id).all()
    
    # Group defects by type for better visualization
    defects_by_type = {}
    for defect in defects:
        if defect.defect_type not in defects_by_type:
            defects_by_type[defect.defect_type] = []
        defects_by_type[defect.defect_type].append(defect)
    
    return render_template('results.html', report=report, defects=defects, defects_by_type=defects_by_type)

@app.route('/generate_report/<int:report_id>')
def generate_report(report_id):
    """Generate PDF report for inspection"""
    try:
        report = InspectionReport.query.get_or_404(report_id)
        defects = DefectDetail.query.filter_by(report_id=report_id).all()
        
        generator = ReportGenerator()
        pdf_filename = f"report_{report_id}_{uuid.uuid4().hex[:8]}.pdf"
        pdf_path = os.path.join(app.config['REPORTS_FOLDER'], pdf_filename)
        
        generator.generate_report(report, defects, pdf_path)
        
        report.report_path = pdf_path
        db.session.commit()
        
        flash('Report generated successfully!', 'success')
        return send_file(pdf_path, as_attachment=True, download_name=f"Infrastructure_Inspection_Report_{report.id}.pdf")
        
    except Exception as e:
        logging.error(f"Error generating report: {str(e)}")
        flash(f'Error generating report: {str(e)}', 'error')
        return redirect(url_for('view_results', report_id=report_id))

@app.route('/reports')
def list_reports():
    """List all inspection reports"""
    page = request.args.get('page', 1, type=int)
    reports = InspectionReport.query.order_by(InspectionReport.created_at.desc()).paginate(
        page=page, per_page=10, error_out=False
    )
    return render_template('reports.html', reports=reports)

@app.route('/delete_report/<int:report_id>', methods=['POST'])
def delete_report(report_id):
    """Delete an inspection report and associated files"""
    try:
        report = InspectionReport.query.get_or_404(report_id)
        
        # Delete associated files
        if report.original_path and os.path.exists(report.original_path):
            os.remove(report.original_path)
        if report.processed_path and os.path.exists(report.processed_path):
            os.remove(report.processed_path)
        if report.report_path and os.path.exists(report.report_path):
            os.remove(report.report_path)
        
        # Delete defect details first (foreign key constraint)
        DefectDetail.query.filter_by(report_id=report_id).delete()
        
        # Delete report
        db.session.delete(report)
        db.session.commit()
        
        flash('Report deleted successfully!', 'success')
        
    except Exception as e:
        logging.error(f"Error deleting report: {str(e)}")
        flash(f'Error deleting report: {str(e)}', 'error')
    
    return redirect(url_for('list_reports'))

@app.route('/ai-explanation')
def ai_explanation():
    """Explain how AI detects defects and generates reports"""
    return render_template('ai_explanation.html')

@app.errorhandler(413)
def too_large(e):
    flash('File is too large. Maximum size is 16MB.', 'error')
    return redirect(url_for('upload'))
