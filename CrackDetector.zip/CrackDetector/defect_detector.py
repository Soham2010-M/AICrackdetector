import cv2
import numpy as np
from PIL import Image
import logging
from typing import List, Dict, Tuple

class DefectDetector:
    """
    Computer vision-based defect detection for civil infrastructure
    Uses traditional CV techniques for crack, corrosion, spalling, and structural damage detection
    """
    
    def __init__(self):
        self.current_image = None
        self.annotated_image = None
        self.detection_results = []
        
        # Detection parameters
        self.crack_params = {
            'canny_low': 50,
            'canny_high': 150,
            'min_line_length': 30,
            'max_line_gap': 10,
            'min_area': 100
        }
        
        self.corrosion_params = {
            'rust_hue_range': [(0, 25), (160, 180)],  # Red-brown hues
            'saturation_threshold': 100,
            'value_threshold': 50,
            'min_area': 200
        }
        
        self.spalling_params = {
            'texture_threshold': 0.02,
            'min_area': 500,
            'aspect_ratio_range': (0.3, 3.0)
        }
    
    def detect_defects(self, image_path: str) -> List[Dict]:
        """
        Main detection function that identifies all types of defects
        """
        self.detection_results = []
        
        try:
            # Load and preprocess image
            self.current_image = cv2.imread(image_path)
            if self.current_image is None:
                raise ValueError(f"Could not load image: {image_path}")
            
            self.annotated_image = self.current_image.copy()
            
            # Detect different types of defects
            self._detect_cracks()
            self._detect_corrosion()
            self._detect_spalling()
            self._detect_structural_damage()
            
            logging.info(f"Detected {len(self.detection_results)} defects in total")
            return self.detection_results
            
        except Exception as e:
            logging.error(f"Error in defect detection: {str(e)}")
            return []
    
    def _detect_cracks(self):
        """Detect cracks using edge detection and morphological operations"""
        gray = cv2.cvtColor(self.current_image, cv2.COLOR_BGR2GRAY)
        
        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Edge detection
        edges = cv2.Canny(blurred, self.crack_params['canny_low'], self.crack_params['canny_high'])
        
        # Morphological operations to connect broken edges
        kernel = np.ones((3, 3), np.uint8)
        dilated = cv2.dilate(edges, kernel, iterations=1)
        eroded = cv2.erode(dilated, kernel, iterations=1)
        
        # Find contours
        contours, _ = cv2.findContours(eroded, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for contour in contours:
            area = cv2.contourArea(contour)
            
            if area > self.crack_params['min_area']:
                # Calculate bounding box
                x, y, w, h = cv2.boundingRect(contour)
                
                # Calculate crack characteristics
                length = self._calculate_crack_length(contour)
                width = area / length if length > 0 else 0
                aspect_ratio = h / w if w > 0 else 0
                
                # Filter based on crack-like characteristics
                if aspect_ratio > 2 or length > 50:  # Long, thin features
                    severity = self._assess_crack_severity(length, width, area)
                    confidence = self._calculate_crack_confidence(contour, aspect_ratio)
                    
                    defect = {
                        'type': 'crack',
                        'severity': severity,
                        'confidence': confidence,
                        'bbox': [x, y, x + w, y + h],
                        'area': area,
                        'length': length,
                        'width': width,
                        'description': f"Linear crack detected with length {length:.1f}px and estimated width {width:.1f}px",
                        'recommendation': self._get_crack_recommendation(severity)
                    }
                    
                    self.detection_results.append(defect)
                    self._draw_detection(defect, (0, 255, 0))  # Green for cracks
    
    def _detect_corrosion(self):
        """Detect corrosion based on color analysis"""
        hsv = cv2.cvtColor(self.current_image, cv2.COLOR_BGR2HSV)
        
        # Create mask for rust-colored regions
        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        
        for hue_range in self.corrosion_params['rust_hue_range']:
            lower_bound = np.array([hue_range[0], self.corrosion_params['saturation_threshold'], 
                                  self.corrosion_params['value_threshold']])
            upper_bound = np.array([hue_range[1], 255, 255])
            
            range_mask = cv2.inRange(hsv, lower_bound, upper_bound)
            mask = cv2.bitwise_or(mask, range_mask)
        
        # Apply morphological operations to clean up the mask
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        
        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for contour in contours:
            area = cv2.contourArea(contour)
            
            if area > self.corrosion_params['min_area']:
                x, y, w, h = cv2.boundingRect(contour)
                
                # Calculate corrosion characteristics
                perimeter = cv2.arcLength(contour, True)
                circularity = 4 * np.pi * area / (perimeter * perimeter) if perimeter > 0 else 0
                
                severity = self._assess_corrosion_severity(area, circularity)
                confidence = self._calculate_corrosion_confidence(mask[y:y+h, x:x+w])
                
                defect = {
                    'type': 'corrosion',
                    'severity': severity,
                    'confidence': confidence,
                    'bbox': [x, y, x + w, y + h],
                    'area': area,
                    'length': max(w, h),
                    'width': min(w, h),
                    'description': f"Corrosion detected covering {area:.0f} square pixels",
                    'recommendation': self._get_corrosion_recommendation(severity)
                }
                
                self.detection_results.append(defect)
                self._draw_detection(defect, (0, 165, 255))  # Orange for corrosion
    
    def _detect_spalling(self):
        """Detect spalling using texture analysis"""
        gray = cv2.cvtColor(self.current_image, cv2.COLOR_BGR2GRAY)
        
        # Calculate local standard deviation (texture measure)
        kernel_size = 15
        kernel = np.ones((kernel_size, kernel_size), np.float32) / (kernel_size * kernel_size)
        mean = cv2.filter2D(gray.astype(np.float32), -1, kernel)
        sqr_diff = (gray.astype(np.float32) - mean) ** 2
        std_dev = np.sqrt(cv2.filter2D(sqr_diff, -1, kernel))
        
        # Normalize standard deviation
        std_dev_norm = std_dev / 255.0
        
        # Create mask for high texture variance areas
        texture_mask = (std_dev_norm > self.spalling_params['texture_threshold']).astype(np.uint8) * 255
        
        # Apply morphological operations
        kernel = np.ones((7, 7), np.uint8)
        texture_mask = cv2.morphologyEx(texture_mask, cv2.MORPH_CLOSE, kernel)
        texture_mask = cv2.morphologyEx(texture_mask, cv2.MORPH_OPEN, kernel)
        
        # Find contours
        contours, _ = cv2.findContours(texture_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for contour in contours:
            area = cv2.contourArea(contour)
            
            if area > self.spalling_params['min_area']:
                x, y, w, h = cv2.boundingRect(contour)
                aspect_ratio = max(w, h) / min(w, h) if min(w, h) > 0 else 0
                
                # Check if aspect ratio is within expected range for spalling
                if (self.spalling_params['aspect_ratio_range'][0] <= aspect_ratio <= 
                    self.spalling_params['aspect_ratio_range'][1]):
                    
                    severity = self._assess_spalling_severity(area, aspect_ratio)
                    confidence = self._calculate_spalling_confidence(std_dev_norm[y:y+h, x:x+w])
                    
                    defect = {
                        'type': 'spalling',
                        'severity': severity,
                        'confidence': confidence,
                        'bbox': [x, y, x + w, y + h],
                        'area': area,
                        'length': max(w, h),
                        'width': min(w, h),
                        'description': f"Surface spalling detected over {area:.0f} square pixels",
                        'recommendation': self._get_spalling_recommendation(severity)
                    }
                    
                    self.detection_results.append(defect)
                    self._draw_detection(defect, (255, 0, 0))  # Blue for spalling
    
    def _detect_structural_damage(self):
        """Detect major structural damage using edge analysis and geometric features"""
        gray = cv2.cvtColor(self.current_image, cv2.COLOR_BGR2GRAY)
        
        # Apply edge detection with different parameters for structural features
        edges = cv2.Canny(gray, 30, 100)
        
        # Find lines using Hough transform
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100, 
                               minLineLength=50, maxLineGap=20)
        
        if lines is not None:
            # Analyze line patterns for structural irregularities
            horizontal_lines = []
            vertical_lines = []
            diagonal_lines = []
            
            for line in lines:
                x1, y1, x2, y2 = line[0]
                angle = np.abs(np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi)
                
                if angle < 15 or angle > 165:  # Horizontal
                    horizontal_lines.append(line[0])
                elif 75 < angle < 105:  # Vertical
                    vertical_lines.append(line[0])
                else:  # Diagonal
                    diagonal_lines.append(line[0])
            
            # Detect structural damage based on line analysis
            self._analyze_structural_lines(horizontal_lines, 'horizontal')
            self._analyze_structural_lines(vertical_lines, 'vertical')
            
            # Excessive diagonal lines may indicate structural failure
            if len(diagonal_lines) > 10:
                self._detect_structural_failure_from_diagonals(diagonal_lines)
    
    def _analyze_structural_lines(self, lines: List, orientation: str):
        """Analyze structural lines for damage patterns"""
        if len(lines) < 3:
            return
        
        # Group nearby parallel lines
        line_groups = self._group_parallel_lines(lines, orientation)
        
        for group in line_groups:
            if len(group) > 2:  # Multiple parallel lines suggest structural elements
                # Calculate bounding box for the group
                all_points = []
                for x1, y1, x2, y2 in group:
                    all_points.extend([(x1, y1), (x2, y2)])
                
                if all_points:
                    x_coords = [p[0] for p in all_points]
                    y_coords = [p[1] for p in all_points]
                    
                    x_min, x_max = min(x_coords), max(x_coords)
                    y_min, y_max = min(y_coords), max(y_coords)
                    
                    area = (x_max - x_min) * (y_max - y_min)
                    
                    if area > 1000:  # Significant structural area
                        severity = self._assess_structural_damage_severity(len(group), area)
                        confidence = 0.7  # Moderate confidence for line-based detection
                        
                        defect = {
                            'type': 'structural_damage',
                            'severity': severity,
                            'confidence': confidence,
                            'bbox': [x_min, y_min, x_max, y_max],
                            'area': area,
                            'length': max(x_max - x_min, y_max - y_min),
                            'width': min(x_max - x_min, y_max - y_min),
                            'description': f"Structural damage detected in {orientation} elements",
                            'recommendation': self._get_structural_damage_recommendation(severity)
                        }
                        
                        self.detection_results.append(defect)
                        self._draw_detection(defect, (0, 0, 255))  # Red for structural damage
    
    def _group_parallel_lines(self, lines: List, orientation: str) -> List[List]:
        """Group parallel lines together"""
        if not lines:
            return []
        
        groups = []
        used_lines = set()
        
        for i, line1 in enumerate(lines):
            if i in used_lines:
                continue
                
            group = [line1]
            used_lines.add(i)
            
            x1, y1, x2, y2 = line1
            
            for j, line2 in enumerate(lines[i+1:], i+1):
                if j in used_lines:
                    continue
                
                x3, y3, x4, y4 = line2
                
                # Check if lines are parallel and close
                if orientation == 'horizontal':
                    if abs(y1 - y3) < 20 and abs(y2 - y4) < 20:  # Similar y-coordinates
                        group.append(line2)
                        used_lines.add(j)
                else:  # vertical
                    if abs(x1 - x3) < 20 and abs(x2 - x4) < 20:  # Similar x-coordinates
                        group.append(line2)
                        used_lines.add(j)
            
            if len(group) > 1:
                groups.append(group)
        
        return groups
    
    def _detect_structural_failure_from_diagonals(self, diagonal_lines: List):
        """Detect potential structural failure from diagonal crack patterns"""
        # Cluster diagonal lines to find major crack systems
        line_clusters = self._cluster_diagonal_lines(diagonal_lines)
        
        for cluster in line_clusters:
            if len(cluster) > 5:  # Significant diagonal cracking
                # Calculate cluster bounding box
                all_points = []
                for x1, y1, x2, y2 in cluster:
                    all_points.extend([(x1, y1), (x2, y2)])
                
                x_coords = [p[0] for p in all_points]
                y_coords = [p[1] for p in all_points]
                
                x_min, x_max = min(x_coords), max(x_coords)
                y_min, y_max = min(y_coords), max(y_coords)
                
                area = (x_max - x_min) * (y_max - y_min)
                
                defect = {
                    'type': 'structural_damage',
                    'severity': 'high',  # Diagonal cracking is typically serious
                    'confidence': 0.8,
                    'bbox': [x_min, y_min, x_max, y_max],
                    'area': area,
                    'length': max(x_max - x_min, y_max - y_min),
                    'width': min(x_max - x_min, y_max - y_min),
                    'description': f"Major structural damage detected - diagonal cracking pattern with {len(cluster)} crack segments",
                    'recommendation': "URGENT: Immediate structural assessment required. Potential load-bearing compromise."
                }
                
                self.detection_results.append(defect)
                self._draw_detection(defect, (0, 0, 255))  # Red for critical damage
    
    def _cluster_diagonal_lines(self, lines: List) -> List[List]:
        """Cluster diagonal lines based on proximity and angle similarity"""
        if not lines:
            return []
        
        clusters = []
        used_lines = set()
        
        for i, line1 in enumerate(lines):
            if i in used_lines:
                continue
            
            cluster = [line1]
            used_lines.add(i)
            
            x1, y1, x2, y2 = line1
            angle1 = np.arctan2(y2 - y1, x2 - x1)
            
            for j, line2 in enumerate(lines[i+1:], i+1):
                if j in used_lines:
                    continue
                
                x3, y3, x4, y4 = line2
                angle2 = np.arctan2(y4 - y3, x4 - x3)
                
                # Check angle similarity and proximity
                angle_diff = abs(angle1 - angle2)
                if angle_diff > np.pi:
                    angle_diff = 2 * np.pi - angle_diff
                
                # Calculate distance between line midpoints
                mid1 = ((x1 + x2) / 2, (y1 + y2) / 2)
                mid2 = ((x3 + x4) / 2, (y3 + y4) / 2)
                distance = np.sqrt((mid1[0] - mid2[0])**2 + (mid1[1] - mid2[1])**2)
                
                if angle_diff < np.pi/6 and distance < 100:  # Similar angle and close proximity
                    cluster.append(line2)
                    used_lines.add(j)
            
            clusters.append(cluster)
        
        return clusters
    
    # Severity assessment methods
    def _assess_crack_severity(self, length: float, width: float, area: float) -> str:
        """Assess crack severity based on dimensions"""
        if length > 200 or width > 5 or area > 2000:
            return 'high'
        elif length > 100 or width > 2 or area > 800:
            return 'medium'
        else:
            return 'low'
    
    def _assess_corrosion_severity(self, area: float, circularity: float) -> str:
        """Assess corrosion severity based on area and spread pattern"""
        severity_score = area / 1000.0
        if circularity < 0.3:  # Irregular, spreading corrosion
            severity_score *= 1.5
        
        if severity_score > 3.0:
            return 'high'
        elif severity_score > 1.0:
            return 'medium'
        else:
            return 'low'
    
    def _assess_spalling_severity(self, area: float, aspect_ratio: float) -> str:
        """Assess spalling severity"""
        if area > 5000 or aspect_ratio > 2.5:
            return 'high'
        elif area > 2000 or aspect_ratio > 1.5:
            return 'medium'
        else:
            return 'low'
    
    def _assess_structural_damage_severity(self, line_count: int, area: float) -> str:
        """Assess structural damage severity"""
        if line_count > 8 or area > 10000:
            return 'high'
        elif line_count > 4 or area > 5000:
            return 'medium'
        else:
            return 'low'
    
    # Confidence calculation methods
    def _calculate_crack_confidence(self, contour, aspect_ratio: float) -> float:
        """Calculate confidence for crack detection"""
        base_confidence = 0.6
        
        # Higher confidence for more crack-like shapes
        if aspect_ratio > 5:
            base_confidence += 0.2
        elif aspect_ratio > 3:
            base_confidence += 0.1
        
        # Consider contour smoothness
        perimeter = cv2.arcLength(contour, True)
        area = cv2.contourArea(contour)
        if perimeter > 0:
            compactness = 4 * np.pi * area / (perimeter * perimeter)
            if compactness < 0.1:  # Very elongated
                base_confidence += 0.1
        
        return min(0.95, base_confidence)
    
    def _calculate_corrosion_confidence(self, mask_region) -> float:
        """Calculate confidence for corrosion detection based on color consistency"""
        if mask_region.size == 0:
            return 0.5
        
        # Calculate the percentage of pixels identified as corrosion
        corrosion_percentage = np.sum(mask_region > 0) / mask_region.size
        
        # Higher percentage indicates more consistent corrosion coloring
        confidence = 0.5 + (corrosion_percentage * 0.4)
        return min(0.9, confidence)
    
    def _calculate_spalling_confidence(self, texture_region) -> float:
        """Calculate confidence for spalling detection based on texture variance"""
        if texture_region.size == 0:
            return 0.5
        
        # Higher texture variance indicates more likely spalling
        variance = np.var(texture_region)
        confidence = 0.4 + (variance * 2.0)
        return min(0.85, confidence)
    
    # Helper methods
    def _calculate_crack_length(self, contour) -> float:
        """Calculate approximate crack length using contour perimeter"""
        return cv2.arcLength(contour, False)
    
    def _draw_detection(self, defect: Dict, color: Tuple[int, int, int]):
        """Draw detection bounding box and label on annotated image"""
        x1, y1, x2, y2 = defect['bbox']
        
        # Draw bounding box
        cv2.rectangle(self.annotated_image, (x1, y1), (x2, y2), color, 2)
        
        # Prepare label
        label = f"{defect['type'].replace('_', ' ').title()}: {defect['severity'].upper()}"
        confidence_text = f"({defect['confidence']:.2f})"
        
        # Calculate text size
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.6
        thickness = 1
        
        (text_width, text_height), _ = cv2.getTextSize(label, font, font_scale, thickness)
        (conf_width, conf_height), _ = cv2.getTextSize(confidence_text, font, font_scale - 0.1, thickness)
        
        # Draw label background
        cv2.rectangle(self.annotated_image, (x1, y1 - text_height - 10), 
                     (x1 + max(text_width, conf_width) + 10, y1), color, -1)
        
        # Draw text
        cv2.putText(self.annotated_image, label, (x1 + 5, y1 - conf_height - 5), 
                   font, font_scale, (255, 255, 255), thickness)
        cv2.putText(self.annotated_image, confidence_text, (x1 + 5, y1 - 2), 
                   font, font_scale - 0.1, (255, 255, 255), thickness)
    
    def save_annotated_image(self, output_path: str):
        """Save the annotated image with detection results"""
        if self.annotated_image is not None:
            cv2.imwrite(output_path, self.annotated_image)
            logging.info(f"Annotated image saved to: {output_path}")
        else:
            logging.warning("No annotated image to save")
    
    # Recommendation methods
    def _get_crack_recommendation(self, severity: str) -> str:
        recommendations = {
            'low': "Monitor crack development. Apply sealant if crack shows signs of growth.",
            'medium': "Schedule repair within 3-6 months. Consider structural assessment if load-bearing element.",
            'high': "Immediate repair required. Conduct structural analysis and implement temporary support if necessary."
        }
        return recommendations.get(severity, "Assess and monitor.")
    
    def _get_corrosion_recommendation(self, severity: str) -> str:
        recommendations = {
            'low': "Clean affected area and apply protective coating. Monitor for progression.",
            'medium': "Remove corrosion, assess structural integrity, and apply corrosion protection system.",
            'high': "Immediate intervention required. Remove corroded material, assess load capacity, and implement comprehensive corrosion protection."
        }
        return recommendations.get(severity, "Assess corrosion extent and treat accordingly.")
    
    def _get_spalling_recommendation(self, severity: str) -> str:
        recommendations = {
            'low': "Clean loose material and apply protective surface treatment.",
            'medium': "Remove all loose material, assess underlying structure, and apply appropriate repair mortar.",
            'high': "Complete removal of damaged material required. Structural assessment needed before repair implementation."
        }
        return recommendations.get(severity, "Remove damaged material and repair.")
    
    def _get_structural_damage_recommendation(self, severity: str) -> str:
        recommendations = {
            'low': "Schedule structural inspection to assess significance and monitor development.",
            'medium': "Immediate structural engineering assessment required. Implement monitoring system.",
            'high': "URGENT: Engage structural engineer immediately. Consider load restrictions and temporary support measures."
        }
        return recommendations.get(severity, "Structural assessment required.")
