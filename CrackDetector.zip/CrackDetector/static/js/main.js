// Civil Infrastructure Defect Detection - Main JavaScript

/**
 * Main application JavaScript file
 * Handles global functionality, UI interactions, and utilities
 */

// Global application object
const InfrastructureApp = {
    // Configuration
    config: {
        maxFileSize: 16 * 1024 * 1024, // 16MB
        allowedFileTypes: ['image/jpeg', 'image/jpg', 'image/png', 'image/bmp', 'image/tiff', 'image/webp'],
        apiEndpoints: {
            upload: '/process_upload',
            reports: '/reports',
            delete: '/delete_report'
        }
    },

    // Initialize the application
    init: function() {
        this.setupEventListeners();
        this.initializeComponents();
        this.setupKeyboardShortcuts();
        console.log('Infrastructure Detection App initialized');
    },

    // Setup global event listeners
    setupEventListeners: function() {
        // Handle page visibility changes
        document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
        
        // Handle window resize
        window.addEventListener('resize', this.debounce(this.handleResize.bind(this), 250));
        
        // Handle beforeunload for unsaved changes
        window.addEventListener('beforeunload', this.handleBeforeUnload.bind(this));

        // Setup error handlers
        window.addEventListener('error', this.handleGlobalError.bind(this));
        window.addEventListener('unhandledrejection', this.handleUnhandledRejection.bind(this));
    },

    // Initialize UI components
    initializeComponents: function() {
        this.initializeTooltips();
        this.initializeModals();
        this.initializeDropdowns();
        this.setupAccessibilityFeatures();
    },

    // Setup keyboard shortcuts
    setupKeyboardShortcuts: function() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + H - Show help
            if ((e.ctrlKey || e.metaKey) && e.key === 'h') {
                e.preventDefault();
                this.showHelp();
            }

            // Escape key - Close modals
            if (e.key === 'Escape') {
                this.closeAllModals();
            }

            // Alt + N - New inspection
            if (e.altKey && e.key === 'n') {
                e.preventDefault();
                window.location.href = '/upload';
            }

            // Alt + D - Dashboard
            if (e.altKey && e.key === 'd') {
                e.preventDefault();
                window.location.href = '/';
            }
        });
    },

    // Utility Functions
    
    // Debounce function
    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // Throttle function
    throttle: function(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },

    // Format file size
    formatFileSize: function(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    // Validate file
    validateFile: function(file) {
        const errors = [];

        if (!file) {
            errors.push('No file selected');
            return errors;
        }

        // Check file type
        if (!this.config.allowedFileTypes.includes(file.type)) {
            errors.push('Invalid file type. Please select an image file.');
        }

        // Check file size
        if (file.size > this.config.maxFileSize) {
            errors.push(`File size must be less than ${this.formatFileSize(this.config.maxFileSize)}`);
        }

        return errors;
    },

    // Show notification
    showNotification: function(message, type = 'info', duration = 5000) {
        const notification = this.createNotificationElement(message, type);
        document.body.appendChild(notification);

        // Show notification
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        // Auto-hide notification
        setTimeout(() => {
            this.hideNotification(notification);
        }, duration);

        return notification;
    },

    // Create notification element
    createNotificationElement: function(message, type) {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 1050; min-width: 300px;';
        
        const iconMap = {
            success: 'check-circle',
            danger: 'exclamation-triangle',
            warning: 'exclamation-circle',
            info: 'info-circle'
        };

        notification.innerHTML = `
            <i class="fas fa-${iconMap[type] || 'info-circle'} me-2"></i>
            ${message}
            <button type="button" class="btn-close" onclick="InfrastructureApp.hideNotification(this.parentElement)"></button>
        `;

        return notification;
    },

    // Hide notification
    hideNotification: function(notification) {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    },

    // Loading overlay functions
    showLoading: function(message = 'Loading...') {
        let overlay = document.getElementById('loadingOverlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'loadingOverlay';
            overlay.className = 'loading-overlay';
            overlay.innerHTML = `
                <div class="text-center">
                    <div class="spinner-border text-primary mb-3" role="status" style="width: 3rem; height: 3rem;">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div class="h5" id="loadingMessage">${message}</div>
                </div>
            `;
            document.body.appendChild(overlay);
        } else {
            document.getElementById('loadingMessage').textContent = message;
            overlay.style.display = 'flex';
        }
    },

    hideLoading: function() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.style.display = 'none';
        }
    },

    // Modal functions
    showModal: function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            const bootstrapModal = new bootstrap.Modal(modal);
            bootstrapModal.show();
            return bootstrapModal;
        }
    },

    hideModal: function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            const bootstrapModal = bootstrap.Modal.getInstance(modal);
            if (bootstrapModal) {
                bootstrapModal.hide();
            }
        }
    },

    closeAllModals: function() {
        const modals = document.querySelectorAll('.modal.show');
        modals.forEach(modal => {
            const bootstrapModal = bootstrap.Modal.getInstance(modal);
            if (bootstrapModal) {
                bootstrapModal.hide();
            }
        });
    },

    // Initialize tooltips
    initializeTooltips: function() {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    },

    // Initialize modals
    initializeModals: function() {
        const modalElements = document.querySelectorAll('.modal');
        modalElements.forEach(modal => {
            modal.addEventListener('shown.bs.modal', this.handleModalShown.bind(this));
            modal.addEventListener('hidden.bs.modal', this.handleModalHidden.bind(this));
        });
    },

    // Initialize dropdowns
    initializeDropdowns: function() {
        const dropdownElements = document.querySelectorAll('.dropdown-toggle');
        dropdownElements.forEach(dropdown => {
            new bootstrap.Dropdown(dropdown);
        });
    },

    // Setup accessibility features
    setupAccessibilityFeatures: function() {
        // Add skip to main content link
        this.addSkipToMainLink();
        
        // Enhance focus management
        this.enhanceFocusManagement();
        
        // Add ARIA labels where needed
        this.addAriaLabels();
    },

    // Add skip to main content link
    addSkipToMainLink: function() {
        const skipLink = document.createElement('a');
        skipLink.href = '#main-content';
        skipLink.className = 'skip-to-main';
        skipLink.textContent = 'Skip to main content';
        document.body.insertBefore(skipLink, document.body.firstChild);

        // Add main content id if not exists
        const main = document.querySelector('main');
        if (main && !main.id) {
            main.id = 'main-content';
        }
    },

    // Enhance focus management
    enhanceFocusManagement: function() {
        // Trap focus in modals
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                const activeModal = document.querySelector('.modal.show');
                if (activeModal) {
                    this.trapFocus(e, activeModal);
                }
            }
        });
    },

    // Trap focus within element
    trapFocus: function(event, element) {
        const focusableElements = element.querySelectorAll(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        const firstFocusable = focusableElements[0];
        const lastFocusable = focusableElements[focusableElements.length - 1];

        if (event.shiftKey) {
            if (document.activeElement === firstFocusable) {
                lastFocusable.focus();
                event.preventDefault();
            }
        } else {
            if (document.activeElement === lastFocusable) {
                firstFocusable.focus();
                event.preventDefault();
            }
        }
    },

    // Add ARIA labels
    addAriaLabels: function() {
        // Add aria-label to buttons without text
        const iconButtons = document.querySelectorAll('button > i:only-child');
        iconButtons.forEach(button => {
            const parent = button.parentElement;
            if (!parent.getAttribute('aria-label') && !parent.getAttribute('title')) {
                const iconClass = button.className;
                if (iconClass.includes('fa-edit')) parent.setAttribute('aria-label', 'Edit');
                else if (iconClass.includes('fa-delete') || iconClass.includes('fa-trash')) parent.setAttribute('aria-label', 'Delete');
                else if (iconClass.includes('fa-view') || iconClass.includes('fa-eye')) parent.setAttribute('aria-label', 'View');
                else if (iconClass.includes('fa-download')) parent.setAttribute('aria-label', 'Download');
            }
        });
    },

    // Event Handlers

    handleVisibilityChange: function() {
        if (document.hidden) {
            console.log('Page hidden');
        } else {
            console.log('Page visible');
        }
    },

    handleResize: function() {
        // Handle responsive layout changes
        this.updateLayoutForScreenSize();
    },

    handleBeforeUnload: function(event) {
        // Check for unsaved changes
        const hasUnsavedChanges = this.checkForUnsavedChanges();
        if (hasUnsavedChanges) {
            event.preventDefault();
            event.returnValue = '';
        }
    },

    handleGlobalError: function(event) {
        console.error('Global error:', event.error);
        this.showNotification('An unexpected error occurred. Please try again.', 'danger');
    },

    handleUnhandledRejection: function(event) {
        console.error('Unhandled promise rejection:', event.reason);
        this.showNotification('A network error occurred. Please check your connection.', 'warning');
    },

    handleModalShown: function(event) {
        const modal = event.target;
        const firstInput = modal.querySelector('input, textarea, select');
        if (firstInput) {
            firstInput.focus();
        }
    },

    handleModalHidden: function(event) {
        // Reset modal content if needed
        const modal = event.target;
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
        }
    },

    // Utility Methods

    updateLayoutForScreenSize: function() {
        const isMobile = window.innerWidth < 768;
        document.body.classList.toggle('mobile', isMobile);
    },

    checkForUnsavedChanges: function() {
        // Check if there are any unsaved form changes
        const forms = document.querySelectorAll('form');
        for (let form of forms) {
            if (form.dataset.dirty === 'true') {
                return true;
            }
        }
        return false;
    },

    // API Utilities

    apiRequest: function(url, options = {}) {
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'same-origin'
        };

        return fetch(url, { ...defaultOptions, ...options })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .catch(error => {
                console.error('API request failed:', error);
                throw error;
            });
    },

    // Chart Utilities

    createChart: function(canvasId, config) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            console.warn(`Canvas element with id '${canvasId}' not found`);
            return null;
        }

        return new Chart(canvas, config);
    },

    // Local Storage Utilities

    saveToLocalStorage: function(key, data) {
        try {
            localStorage.setItem(key, JSON.stringify(data));
        } catch (error) {
            console.warn('Failed to save to localStorage:', error);
        }
    },

    loadFromLocalStorage: function(key) {
        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.warn('Failed to load from localStorage:', error);
            return null;
        }
    },

    removeFromLocalStorage: function(key) {
        try {
            localStorage.removeItem(key);
        } catch (error) {
            console.warn('Failed to remove from localStorage:', error);
        }
    },

    // Public API Methods (called from templates)

    showHelp: function() {
        this.showModal('helpModal');
    },

    showAbout: function() {
        this.showModal('aboutModal');
    },

    confirmDelete: function(id, type = 'item') {
        return confirm(`Are you sure you want to delete this ${type}? This action cannot be undone.`);
    }
};

// Form tracking for unsaved changes
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('change', () => {
                form.dataset.dirty = 'true';
            });
        });

        form.addEventListener('submit', () => {
            form.dataset.dirty = 'false';
        });
    });
});

// Global helper functions (called from templates)
function showHelp() {
    InfrastructureApp.showHelp();
}

function showAbout() {
    InfrastructureApp.showAbout();
}

function confirmDelete(id, type = 'item') {
    return InfrastructureApp.confirmDelete(id, type);
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    InfrastructureApp.init();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = InfrastructureApp;
}
