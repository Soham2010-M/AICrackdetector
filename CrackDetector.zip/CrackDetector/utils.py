import os
import uuid
from werkzeug.utils import secure_filename
from PIL import Image
import logging

def allowed_file(filename, allowed_extensions):
    """Check if file has an allowed extension"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in allowed_extensions

def generate_unique_filename(original_filename):
    """Generate a unique filename while preserving the extension"""
    name, ext = os.path.splitext(secure_filename(original_filename))
    unique_name = f"{uuid.uuid4().hex}_{name}{ext}"
    return unique_name

def validate_image(file_path):
    """Validate that the uploaded file is a valid image"""
    try:
        with Image.open(file_path) as img:
            img.verify()
        return True
    except Exception as e:
        logging.error(f"Invalid image file {file_path}: {str(e)}")
        return False

def get_image_info(file_path):
    """Get basic information about an image file"""
    try:
        with Image.open(file_path) as img:
            return {
                'width': img.width,
                'height': img.height,
                'format': img.format,
                'mode': img.mode,
                'size_bytes': os.path.getsize(file_path)
            }
    except Exception as e:
        logging.error(f"Error getting image info for {file_path}: {str(e)}")
        return None

def format_file_size(size_bytes):
    """Convert bytes to human readable format"""
    if size_bytes == 0:
        return "0B"
    
    size_names = ["B", "KB", "MB", "GB"]
    import math
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_names[i]}"

def clean_old_files(directory, max_age_hours=24):
    """Clean up old files from a directory"""
    import time
    
    if not os.path.exists(directory):
        return
    
    current_time = time.time()
    max_age_seconds = max_age_hours * 3600
    
    try:
        for filename in os.listdir(directory):
            file_path = os.path.join(directory, filename)
            if os.path.isfile(file_path):
                file_age = current_time - os.path.getctime(file_path)
                if file_age > max_age_seconds:
                    os.remove(file_path)
                    logging.info(f"Cleaned up old file: {file_path}")
    except Exception as e:
        logging.error(f"Error cleaning up directory {directory}: {str(e)}")

def create_thumbnail(image_path, thumbnail_path, max_size=(300, 300)):
    """Create a thumbnail version of an image"""
    try:
        with Image.open(image_path) as img:
            img.thumbnail(max_size, Image.Resampling.LANCZOS)
            img.save(thumbnail_path, optimize=True, quality=85)
        return True
    except Exception as e:
        logging.error(f"Error creating thumbnail for {image_path}: {str(e)}")
        return False

def ensure_directory_exists(directory_path):
    """Ensure a directory exists, create if it doesn't"""
    try:
        os.makedirs(directory_path, exist_ok=True)
        return True
    except Exception as e:
        logging.error(f"Error creating directory {directory_path}: {str(e)}")
        return False

def safe_filename(filename):
    """Create a safe filename by removing problematic characters"""
    import re
    # Remove or replace problematic characters
    safe_name = re.sub(r'[^\w\s-.]', '', filename)
    safe_name = re.sub(r'[-\s]+', '-', safe_name)
    return safe_name.strip('-')

def get_severity_color_class(severity):
    """Get CSS class name for severity level"""
    severity_classes = {
        'low': 'success',
        'medium': 'warning', 
        'high': 'danger'
    }
    return severity_classes.get(severity, 'secondary')

def calculate_risk_level(defects):
    """Calculate overall risk level based on defects"""
    if not defects:
        return 'low', 0.0
    
    high_count = sum(1 for d in defects if d.severity == 'high')
    medium_count = sum(1 for d in defects if d.severity == 'medium')
    low_count = sum(1 for d in defects if d.severity == 'low')
    
    # Calculate weighted risk score
    risk_score = (high_count * 0.8 + medium_count * 0.4 + low_count * 0.1) / len(defects)
    
    if high_count > 0 or risk_score > 0.6:
        return 'high', risk_score
    elif medium_count > 0 or risk_score > 0.3:
        return 'medium', risk_score
    else:
        return 'low', risk_score
