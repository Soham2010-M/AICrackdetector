import os
from datetime import datetime
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.colors import Color, black, red, orange, green
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.graphics.shapes import Drawing, Rect
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.lib import colors
import matplotlib.pyplot as plt
import numpy as np
from io import BytesIO
import base64
import logging

class ReportGenerator:
    """
    Professional PDF report generator for civil infrastructure inspection results
    """
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
        
        # Severity colors
        self.severity_colors = {
            'low': colors.green,
            'medium': colors.orange,
            'high': colors.red
        }
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles for professional formatting"""
        # Title style
        self.styles.add(ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Title'],
            fontSize=24,
            spaceAfter=30,
            textColor=Color(0.2, 0.2, 0.5),
            alignment=TA_CENTER
        ))
        
        # Header style
        self.styles.add(ParagraphStyle(
            'CustomHeader',
            parent=self.styles['Heading1'],
            fontSize=16,
            spaceBefore=20,
            spaceAfter=12,
            textColor=Color(0.2, 0.2, 0.5),
            borderWidth=1,
            borderColor=Color(0.2, 0.2, 0.5),
            borderPadding=5
        ))
        
        # Subheader style
        self.styles.add(ParagraphStyle(
            'CustomSubHeader',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceBefore=15,
            spaceAfter=8,
            textColor=Color(0.3, 0.3, 0.6)
        ))
        
        # Summary box style
        self.styles.add(ParagraphStyle(
            'SummaryBox',
            parent=self.styles['Normal'],
            fontSize=12,
            spaceBefore=10,
            spaceAfter=10,
            borderWidth=1,
            borderColor=Color(0.7, 0.7, 0.7),
            borderPadding=10,
            backColor=Color(0.95, 0.95, 0.98)
        ))
    
    def generate_report(self, inspection_report, defects, output_path: str):
        """Generate comprehensive PDF inspection report"""
        try:
            doc = SimpleDocTemplate(
                output_path,
                pagesize=A4,
                rightMargin=72,
                leftMargin=72,
                topMargin=72,
                bottomMargin=18
            )
            
            # Build report content
            story = []
            
            # Title page
            self._add_title_page(story, inspection_report)
            story.append(PageBreak())
            
            # Executive summary
            self._add_executive_summary(story, inspection_report, defects)
            
            # Detailed findings
            self._add_detailed_findings(story, inspection_report, defects)
            
            # Visual analysis
            if inspection_report.processed_path and os.path.exists(inspection_report.processed_path):
                self._add_visual_analysis(story, inspection_report)
            
            # Recommendations
            self._add_recommendations(story, defects)
            
            # Appendices
            self._add_appendices(story, inspection_report, defects)
            
            # Build PDF
            doc.build(story)
            logging.info(f"Report generated successfully: {output_path}")
            
        except Exception as e:
            logging.error(f"Error generating report: {str(e)}")
            raise
    
    def _add_title_page(self, story, report):
        """Add professional title page"""
        # Main title
        title = Paragraph("CIVIL INFRASTRUCTURE<br/>DEFECT INSPECTION REPORT", self.styles['CustomTitle'])
        story.append(title)
        story.append(Spacer(1, 50))
        
        # Report details table
        report_data = [
            ['Report ID:', f"INS-{report.id:06d}"],
            ['Inspection Date:', report.created_at.strftime('%B %d, %Y')],
            ['Infrastructure Type:', report.infrastructure_type or 'General Structure'],
            ['Location:', report.location or 'Not specified'],
            ['Original Filename:', report.filename],
            ['Overall Risk Level:', self._format_severity(report.overall_severity)],
            ['Risk Score:', f"{report.risk_score:.2%}"]
        ]
        
        report_table = Table(report_data, colWidths=[2*inch, 3*inch])
        report_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 12),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('BACKGROUND', (0, 0), (0, -1), Color(0.9, 0.9, 0.9))
        ]))
        
        story.append(report_table)
        story.append(Spacer(1, 50))
        
        # Add defect summary chart
        if report.total_defects > 0:
            self._add_defect_summary_chart(story, report)
        
        # Footer
        story.append(Spacer(1, 100))
        footer_text = Paragraph(
            "This report contains confidential and proprietary information.<br/>"
            "Generated by Civil Infrastructure Defect Detection System",
            self.styles['Normal']
        )
        story.append(footer_text)
    
    def _add_defect_summary_chart(self, story, report):
        """Add pie chart showing defect type distribution"""
        # Collect defect counts
        defect_data = {}
        if report.crack_count > 0:
            defect_data['Cracks'] = report.crack_count
        if report.corrosion_count > 0:
            defect_data['Corrosion'] = report.corrosion_count
        if report.spalling_count > 0:
            defect_data['Spalling'] = report.spalling_count
        if report.structural_damage_count > 0:
            defect_data['Structural Damage'] = report.structural_damage_count
        
        if defect_data:
            # Create matplotlib chart
            fig, ax = plt.subplots(figsize=(6, 4))
            colors_list = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
            
            wedges, texts, autotexts = ax.pie(
                defect_data.values(),
                labels=defect_data.keys(),
                autopct='%1.0f%%',
                colors=colors_list[:len(defect_data)],
                startangle=90
            )
            
            ax.set_title('Detected Defects by Type', fontsize=14, fontweight='bold')
            
            # Save chart to bytes
            img_buffer = BytesIO()
            plt.savefig(img_buffer, format='png', dpi=150, bbox_inches='tight')
            img_buffer.seek(0)
            plt.close()
            
            # Add chart to story
            chart_image = Image(img_buffer, width=4*inch, height=2.7*inch)
            story.append(chart_image)
    
    def _add_executive_summary(self, story, report, defects):
        """Add executive summary section"""
        story.append(Paragraph("EXECUTIVE SUMMARY", self.styles['CustomHeader']))
        
        # Overall assessment
        risk_level = report.overall_severity.upper()
        risk_color = self.severity_colors.get(report.overall_severity, colors.black)
        
        summary_text = f"""
        <b>Overall Risk Assessment: <font color="{risk_color}">{risk_level}</font></b><br/><br/>
        
        This inspection identified <b>{report.total_defects}</b> defects across the analyzed infrastructure component. 
        The risk score of <b>{report.risk_score:.1%}</b> indicates a <b>{risk_level.lower()}</b> priority level for remediation actions.
        """
        
        if report.total_defects > 0:
            summary_text += f"""<br/><br/>
            <b>Defect Breakdown:</b><br/>
            • Cracks: {report.crack_count}<br/>
            • Corrosion: {report.corrosion_count}<br/>
            • Spalling: {report.spalling_count}<br/>
            • Structural Damage: {report.structural_damage_count}
            """
        
        story.append(Paragraph(summary_text, self.styles['SummaryBox']))
        
        # Key findings
        story.append(Spacer(1, 20))
        story.append(Paragraph("Key Findings", self.styles['CustomSubHeader']))
        
        high_severity_defects = [d for d in defects if d.severity == 'high']
        medium_severity_defects = [d for d in defects if d.severity == 'medium']
        
        findings_text = ""
        
        if high_severity_defects:
            findings_text += f"• <b>{len(high_severity_defects)}</b> high-severity defects requiring immediate attention<br/>"
        
        if medium_severity_defects:
            findings_text += f"• <b>{len(medium_severity_defects)}</b> medium-severity defects requiring scheduled maintenance<br/>"
        
        if not high_severity_defects and not medium_severity_defects:
            findings_text += "• No critical defects identified in this inspection<br/>"
        
        # Add infrastructure-specific findings
        if report.infrastructure_type:
            findings_text += f"• Analysis performed on {report.infrastructure_type.lower()} structure<br/>"
        
        story.append(Paragraph(findings_text, self.styles['Normal']))
    
    def _add_detailed_findings(self, story, report, defects):
        """Add detailed findings section"""
        story.append(PageBreak())
        story.append(Paragraph("DETAILED FINDINGS", self.styles['CustomHeader']))
        
        if not defects:
            story.append(Paragraph("No defects were identified in this inspection.", self.styles['Normal']))
            return
        
        # Group defects by type
        defects_by_type = {}
        for defect in defects:
            if defect.defect_type not in defects_by_type:
                defects_by_type[defect.defect_type] = []
            defects_by_type[defect.defect_type].append(defect)
        
        # Detail each defect type
        for defect_type, type_defects in defects_by_type.items():
            story.append(Paragraph(
                f"{defect_type.replace('_', ' ').title()} ({len(type_defects)} detected)",
                self.styles['CustomSubHeader']
            ))
            
            # Create table for this defect type
            table_data = [['ID', 'Severity', 'Confidence', 'Dimensions', 'Description']]
            
            for i, defect in enumerate(type_defects, 1):
                # Use simple text for severity without HTML formatting in tables
                severity_text = defect.severity.upper()
                dimensions = f"{defect.length:.0f} × {defect.width:.0f} px"
                
                table_data.append([
                    str(i),
                    severity_text,
                    f"{defect.confidence:.1%}",
                    dimensions,
                    defect.description[:60] + "..." if len(defect.description) > 60 else defect.description
                ])
            
            defect_table = Table(table_data, colWidths=[0.5*inch, 1*inch, 1*inch, 1.5*inch, 2.5*inch])
            
            # Create table style with severity color coding
            table_style = [
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey)
            ]
            
            # Add color coding for severity column based on each row
            for i, defect in enumerate(type_defects, 1):
                row_idx = i  # i is already 1-based for data rows
                if defect.severity == 'high':
                    table_style.append(('TEXTCOLOR', (1, row_idx), (1, row_idx), colors.red))
                    table_style.append(('FONTNAME', (1, row_idx), (1, row_idx), 'Helvetica-Bold'))
                elif defect.severity == 'medium':
                    table_style.append(('TEXTCOLOR', (1, row_idx), (1, row_idx), colors.orange))
                    table_style.append(('FONTNAME', (1, row_idx), (1, row_idx), 'Helvetica-Bold'))
                elif defect.severity == 'low':
                    table_style.append(('TEXTCOLOR', (1, row_idx), (1, row_idx), colors.green))
                    table_style.append(('FONTNAME', (1, row_idx), (1, row_idx), 'Helvetica-Bold'))
            
            defect_table.setStyle(TableStyle(table_style))
            
            story.append(defect_table)
            story.append(Spacer(1, 20))
    
    def _add_visual_analysis(self, story, report):
        """Add visual analysis section with processed image"""
        story.append(PageBreak())
        story.append(Paragraph("VISUAL ANALYSIS", self.styles['CustomHeader']))
        
        story.append(Paragraph(
            "The following image shows the analyzed structure with detected defects highlighted and annotated:",
            self.styles['Normal']
        ))
        story.append(Spacer(1, 12))
        
        try:
            # Add processed image
            processed_image = Image(report.processed_path, width=6*inch, height=4.5*inch)
            story.append(processed_image)
            
            # Add image caption
            caption = Paragraph(
                f"<i>Figure 1: Processed analysis of {report.filename} showing detected defects with severity classification</i>",
                self.styles['Normal']
            )
            story.append(Spacer(1, 6))
            story.append(caption)
            
        except Exception as e:
            story.append(Paragraph(
                f"Error loading processed image: {str(e)}",
                self.styles['Normal']
            ))
    
    def _add_recommendations(self, story, defects):
        """Add recommendations section"""
        story.append(PageBreak())
        story.append(Paragraph("RECOMMENDATIONS", self.styles['CustomHeader']))
        
        if not defects:
            story.append(Paragraph(
                "Continue regular monitoring and maintenance schedule. No immediate actions required based on this inspection.",
                self.styles['Normal']
            ))
            return
        
        # Categorize recommendations by urgency
        urgent_recommendations = []
        scheduled_recommendations = []
        monitoring_recommendations = []
        
        for defect in defects:
            if defect.recommendation:
                if defect.severity == 'high':
                    urgent_recommendations.append(defect.recommendation)
                elif defect.severity == 'medium':
                    scheduled_recommendations.append(defect.recommendation)
                else:
                    monitoring_recommendations.append(defect.recommendation)
        
        # Immediate Actions (High Priority)
        if urgent_recommendations:
            story.append(Paragraph("IMMEDIATE ACTIONS REQUIRED", self.styles['CustomSubHeader']))
            story.append(Paragraph(
                '<font color="red"><b>The following items require immediate attention:</b></font>',
                self.styles['Normal']
            ))
            
            for i, rec in enumerate(set(urgent_recommendations), 1):
                story.append(Paragraph(f"{i}. {rec}", self.styles['Normal']))
            
            story.append(Spacer(1, 15))
        
        # Scheduled Maintenance (Medium Priority)
        if scheduled_recommendations:
            story.append(Paragraph("SCHEDULED MAINTENANCE", self.styles['CustomSubHeader']))
            story.append(Paragraph(
                '<font color="orange"><b>Plan the following maintenance activities:</b></font>',
                self.styles['Normal']
            ))
            
            for i, rec in enumerate(set(scheduled_recommendations), 1):
                story.append(Paragraph(f"{i}. {rec}", self.styles['Normal']))
            
            story.append(Spacer(1, 15))
        
        # Ongoing Monitoring (Low Priority)
        if monitoring_recommendations:
            story.append(Paragraph("ONGOING MONITORING", self.styles['CustomSubHeader']))
            story.append(Paragraph(
                '<font color="green"><b>Include in regular maintenance checks:</b></font>',
                self.styles['Normal']
            ))
            
            for i, rec in enumerate(set(monitoring_recommendations), 1):
                story.append(Paragraph(f"{i}. {rec}", self.styles['Normal']))
    
    def _add_appendices(self, story, report, defects):
        """Add appendices with technical details"""
        story.append(PageBreak())
        story.append(Paragraph("APPENDICES", self.styles['CustomHeader']))
        
        # Appendix A: Technical Details
        story.append(Paragraph("Appendix A: Technical Analysis Details", self.styles['CustomSubHeader']))
        
        tech_details = f"""
        <b>Analysis Parameters:</b><br/>
        • Detection Method: Computer Vision Analysis<br/>
        • Image Resolution: Processed at full resolution<br/>
        • Analysis Date: {report.created_at.strftime('%Y-%m-%d %H:%M:%S')}<br/>
        • Processing Time: Automated analysis<br/><br/>
        
        <b>Detection Algorithms:</b><br/>
        • Crack Detection: Edge detection with morphological analysis<br/>
        • Corrosion Detection: HSV color space analysis<br/>
        • Spalling Detection: Texture variance analysis<br/>
        • Structural Damage: Line pattern analysis<br/><br/>
        
        <b>Confidence Scoring:</b><br/>
        Confidence levels indicate the algorithm's certainty in defect identification:
        • High (>80%): Very reliable detection<br/>
        • Medium (60-80%): Good detection with minor uncertainty<br/>
        • Low (<60%): Possible defect requiring manual verification
        """
        
        story.append(Paragraph(tech_details, self.styles['Normal']))
        
        # Appendix B: Defect Classification
        if defects:
            story.append(Spacer(1, 20))
            story.append(Paragraph("Appendix B: Complete Defect Registry", self.styles['CustomSubHeader']))
            
            # Create comprehensive defect table
            table_data = [['#', 'Type', 'Severity', 'Confidence', 'Location (pixels)', 'Area', 'Description']]
            
            for i, defect in enumerate(defects, 1):
                location = f"({defect.x_min}, {defect.y_min})"
                area_text = f"{defect.area:.0f} px²" if defect.area else "N/A"
                
                table_data.append([
                    str(i),
                    defect.defect_type.replace('_', ' ').title(),
                    defect.severity.capitalize(),
                    f"{defect.confidence:.1%}",
                    location,
                    area_text,
                    defect.description[:40] + "..." if len(defect.description) > 40 else defect.description
                ])
            
            defect_registry = Table(table_data, colWidths=[0.3*inch, 1*inch, 0.8*inch, 0.8*inch, 1*inch, 0.8*inch, 2*inch])
            defect_registry.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 8),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('BACKGROUND', (0, 0), (-1, 0), Color(0.8, 0.8, 0.8))
            ]))
            
            story.append(defect_registry)
        
        # Appendix C: Inspector Notes
        if report.inspector_notes:
            story.append(Spacer(1, 20))
            story.append(Paragraph("Appendix C: Inspector Notes", self.styles['CustomSubHeader']))
            story.append(Paragraph(report.inspector_notes, self.styles['Normal']))
    
    def _format_severity(self, severity: str) -> str:
        """Format severity with appropriate color coding"""
        color = self.severity_colors.get(severity, colors.black)
        return f'<font color="{color}">{severity.upper()}</font>'
