from app import db
from datetime import datetime
from sqlalchemy import Text, Float, Integer, String, DateTime, Boolean

class InspectionReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    original_path = db.Column(db.String(500), nullable=False)
    processed_path = db.Column(db.String(500))
    report_path = db.Column(db.String(500))
    
    # Detection results
    total_defects = db.Column(db.Integer, default=0)
    crack_count = db.Column(db.Integer, default=0)
    corrosion_count = db.Column(db.Integer, default=0)
    spalling_count = db.Column(db.Integer, default=0)
    structural_damage_count = db.Column(db.Integer, default=0)
    
    # Severity assessment
    overall_severity = db.Column(db.String(20))  # low, medium, high
    risk_score = db.Column(db.Float, default=0.0)
    
    # Metadata
    infrastructure_type = db.Column(db.String(100))
    location = db.Column(db.String(200))
    inspector_notes = db.Column(Text)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<InspectionReport {self.filename}>'

class DefectDetail(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    report_id = db.Column(db.Integer, db.ForeignKey('inspection_report.id'), nullable=False)
    
    defect_type = db.Column(db.String(50), nullable=False)  # crack, corrosion, spalling, structural_damage
    severity = db.Column(db.String(20), nullable=False)  # low, medium, high
    confidence = db.Column(db.Float, nullable=False)
    
    # Bounding box coordinates
    x_min = db.Column(db.Integer)
    y_min = db.Column(db.Integer)
    x_max = db.Column(db.Integer)
    y_max = db.Column(db.Integer)
    
    # Area and dimensions
    area = db.Column(db.Float)
    length = db.Column(db.Float)
    width = db.Column(db.Float)
    
    description = db.Column(Text)
    recommendation = db.Column(Text)
    
    report = db.relationship('InspectionReport', backref=db.backref('defects', lazy=True))
    
    def __repr__(self):
        return f'<DefectDetail {self.defect_type} - {self.severity}>'
